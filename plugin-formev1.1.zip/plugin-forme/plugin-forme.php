<?php
/*
Plugin Name: FormE
Plugin URI: https://lucascruz.dev.br/plugins/forme
Description: Um plugin de formulário de contato para WordPress
Version: 1.1
Author: Lucas Cruz
Author URI: https://lucascruz.dev.br
*/

//adicionar plugin ao menu
function formE_menu()
{
  add_menu_page('FormE', 'FormE', 'manage_options', 'formE', 'formE_page', 'dashicons-admin-generic', 20);
}
add_action('admin_menu', 'formE_menu');

//criar página do plugin com um h1
function formE_page()
{
  echo '<h1>FormE</h1>';
  echo '<p>Instruções para uso do plugin FormE</p>';
  echo '<p>Para adicionar o formulário de contato em uma página ou postagem, basta inserir o shortcode [meu_plugin_contato] no conteúdo da página ou postagem.</p>';
}

// Adiciona um atalho para exibir o formulário de contato em uma página ou postagem
add_shortcode('meu_plugin_contato', 'meu_plugin_contato_shortcode');
function meu_plugin_contato_shortcode()
{
  ob_start();
  include_once(plugin_dir_path(__FILE__) . 'form.php');
  return ob_get_clean();
}

// Formulário de contato
add_action('admin_post_contact_form', 'meu_plugin_contato_processar_form');
function meu_plugin_contato_processar_form(){
  // Verifica se o formulário foi enviado
  if (isset($_POST['meu_plugin_contato_submit'])) {

    // Recupera os dados do formulário
    $nome = sanitize_text_field($_POST['name']);
    $email = sanitize_email($_POST['email']);
    //$assunto = sanitize_text_field($_POST['subject']);
    //$mensagem = sanitize_textarea_field($_POST['message']);
    $referrer = sanitize_text_field($_POST['referrer']);

    // Adicione aqui o código para processar o envio do formulário
    // ...
    // Configura as informações do e-mail
    $para = 'lucas_empresa@yahoo.com.br';
    $assunto = 'Contato do site';
    $corpo = "Nome: $nome\nEmail: $email\nEnviado de: $referrer";

    // Envia o e-mail
    if (wp_mail($para, $assunto, $corpo)) {
      // Redireciona para a página de agradecimento
      wp_redirect('./obrigado/');
      exit;
    } else {
      // Redireciona para a página de erro
      wp_die('Erro: O envio do formulário não foi realizado corretamente.');
      exit;
    }
  }
}
