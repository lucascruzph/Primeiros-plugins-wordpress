<?php
/*
Plugin Name: Inserir HBF

*/

function my_header_code()
{
    $header_code = get_option('header_code');
    echo $header_code;
}
add_action('wp_head', 'my_header_code');

function my_body_code()
{
    $body_code = get_option('body_code');
    echo $body_code;
}
add_action('wp_body_open', 'my_body_code');

function my_footer_code()
{
    $footer_code = get_option('footer_code');
    echo $footer_code;
}
add_action('wp_footer', 'my_footer_code');

// Adicionar menu de opções
function wp_header_body_footer_code_page() {
    my_plugin_options();
  }
  
function wp_header_body_footer_code_menu() {
    add_menu_page( 'Inserir HBF', 'Inserir HBF', 'manage_options', 'wp-header-body-footer-code', 'wp_header_body_footer_code_page', 'dashicons-admin-generic', 20 );
  }
  add_action( 'admin_menu', 'wp_header_body_footer_code_menu' );

function my_plugin_options()
{
    if (!current_user_can('manage_options')) {
        wp_die(__('Você não tem permissão para acessar esta página.'));
    }
    echo '<div class="wrap">';
    echo '<h2>Inserir código</h2>';
    echo '<form method="post" action="options.php">';
    settings_fields('inserir-codigo-group');
    do_settings_sections('inserir-codigo-group');
    echo '<table class="form-table">';
    echo '<tr valign="top">';
    echo '<th scope="row">Código no header</th>';
    echo '<td><textarea name="header_code" rows="10" cols="50" id="header_code">' . esc_attr(get_option('header_code')) . '</textarea></td>';
    echo '</tr>';
    echo '<tr valign="top">';
    echo '<th scope="row">Código no corpo</th>';
    echo '<td><textarea name="body_code" rows="10" cols="50" id="body_code">' . esc_attr(get_option('body_code')) . '</textarea></td>';
    echo '</tr>';
    echo '<tr valign="top">';
    echo '<th scope="row">Código no footer</th>';
    echo '<td><textarea name="footer_code" rows="10" cols="50" id="footer_code">' . esc_attr(get_option('footer_code')) . '</textarea></td>';
    echo '</tr>';
    echo '</table>';
    submit_button();
    echo '</form>';
    echo '</div>';

    echo '<script>
    var headerCodeEditor = CodeMirror.fromTextArea(document.getElementById("header_code"), {
    mode: "text/html",
    theme: "monokai",
    lineNumbers: true
    });
    var bodyCodeEditor = CodeMirror.fromTextArea(document.getElementById("body_code"), {
    mode: "text/html",
    theme: "monokai",
    lineNumbers: true
    });
    var footerCodeEditor = CodeMirror.fromTextArea(document.getElementById("footer_code"), {
    mode: "text/html",
    theme: "monokai",
    lineNumbers: true
    });
    </script>';
}


// Registrar opções
add_action('admin_init', 'register_my_plugin_settings');

function register_my_plugin_settings()
{
    register_setting('inserir-codigo-group', 'header_code');
    register_setting('inserir-codigo-group', 'body_code');
    register_setting('inserir-codigo-group', 'footer_code');
}

function custom_admin_scripts()
{
    // Carregar o CodeMirror
    wp_enqueue_script('codemirror', 'https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.56.0/codemirror.min.js');
    wp_enqueue_style('codemirror', 'https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.56.0/codemirror.min.css');
    wp_enqueue_style('codemirror-theme', 'https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.56.0/theme/monokai.min.css');
}
add_action('admin_enqueue_scripts', 'custom_admin_scripts');

