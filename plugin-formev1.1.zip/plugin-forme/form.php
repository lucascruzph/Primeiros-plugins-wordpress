<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
    <div>
        <label for="name" name="name">Nome:</label>
        <input type="text" name="name" id="name" required>
    </div>
    <div>
        <label for="email" name="email">E-mail:</label>
        <input type="email" name="email" id="email" required>
    </div>
    <!--
    <div>
        <label for="subject" name="subject">Assunto:</label>
        <input type="text" name="subject" id="subject" required>
    </div>
    <div>
        <label for="message" name="message">Mensagem:</label>
        <textarea name="message" id="message" rows="5" required></textarea>
    </div>
    -->

    <input type="hidden" name="action" value="contact_form">
    <?php wp_nonce_field('contact_form', 'contact_form_nonce'); ?>

    <!--Input com script para capturar os dados do document.referrer-->
    <!--que é a página de onde o usuário veio para acessar a página do formulário-->
    <input type="hidden" name="referrer" id="referrer" value="">

    <input type="submit" value="Enviar" name="meu_plugin_contato_submit">
</form>

<script>
        // Define o valor do campo 'referrer' com o valor de document.referrer
        
    document.getElementById('referrer').value = document.referrer;
</script>